import React from 'react';

const SeasonDisplay = () => {
  return <div>Season Display</div>;
};

export default SeasonDisplay;
